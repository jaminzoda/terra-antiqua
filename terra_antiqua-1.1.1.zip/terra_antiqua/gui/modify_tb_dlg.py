#Copyright (C) 2021 by Jovid Aminov, Diego Ruiz, Guillaume Dupont-Nivet
#Terra Antiqua is a plugin for the software QGis that deals with the reconstruction of paleogeography.
#Full copyright notice in file: terra_antiqua.py
# [QGIS4 port] Changes made in v1.1.1 for QGIS 4 compatibility (lines marked "# [QGIS4 port]"):
#  - Imports switched from PyQt5 to qgis.PyQt (works with both Qt5 and Qt6)
#  - Python built-ins abs, bool, max, min, pow and round restored after "from numpy import *",
#    because NumPy 2 (bundled with QGIS 4) would otherwise replace them
#  - formulaValidation: uses core/expressions.evaluate instead of eval()
#  - Errors that are deliberately ignored are recorded with compat.ignored() instead of a silent "pass"
#  - Random numbers come from NumPy (compat.random_generator) instead of Python's random module (formula test data)
#  See core/compat.py for the note on how this port was made.


from qgis.PyQt import QtWidgets  # [QGIS4 port]
from .base_dialog import TaBaseDialog
from .widgets import (
    TaRasterLayerComboBox,
    TaVectorLayerComboBox,
    TaSpinBox,
    TaCheckBox,
    TaExpressionWidget,
    TaColorSchemeWidget
)
from numpy import * #This is to use math functions for formula validation
# NumPy 2.x (bundled with QGIS 4) also exports abs, bool, max, min, pow and round, which would
# replace Python's built-ins in this module. Restore them so behaviour matches NumPy 1.x.
from builtins import abs, bool, max, min, pow, round  # noqa: E402,F811  # [QGIS4 port]
from ..core.expressions import evaluate  # noqa: E402  # [QGIS4 port]
from ..core.compat import random_generator  # noqa: E402  # [QGIS4 port]
from ..core.compat import ignored  # [QGIS4 port]


class TaModifyTopoBathyDlg(TaBaseDialog):
    def __init__(self, parent=None):
        super(TaModifyTopoBathyDlg, self).__init__(parent)
        self.defineParameters()
        self.masksBox.layerChanged.connect(self.setFieldsInLayer)
    def defineParameters(self):
        self.baseTopoBox = self.addMandatoryParameter(
            TaRasterLayerComboBox,
            "Select the topography raster for modification:",
            "TaMapLayerComboBox")
        self.masksBox = self.addMandatoryParameter(
                                    TaVectorLayerComboBox,
                                    "Select vector layer containing masks:",
                                    "TaMapLayerComboBox")
        self.selectedFeaturesBox = self.addParameter(
                                    TaCheckBox,
                                    "Selected features only",
                                   "CheckBox")
        try:
            self.selectedFeaturesBox.registerLinkedWidget(self.masksBox)
        except Exception as e:  # [QGIS4 port]
            ignored(e)  # [QGIS4 port]
        self.modificationModeComboBox = self.addParameter(
                                            QtWidgets.QComboBox,
                                            "Topography modification mode:")
        self.modificationModeComboBox.addItems([
                                            'Modify with formula',
                                            'Rescale with final minimum and maximum values'])
        # The formula modification parameters
        self.formulaField = self.addVariantParameter(
                                    TaExpressionWidget,
                                    "Modify with formula",
                                    "Select the formula field or type the formula:")
        self.formulaField.lineEdit.editingFinished.connect(self.formulaValidation)
        self.min_maxValueCheckBox = self.addVariantParameter(
                                        TaCheckBox,
                                        "Modify with formula",
                                        "Constrain values to be modified with minimum and maximum",
                                        "CheckBox")
        self.minValueSpin= self.addVariantParameter(
                                    TaSpinBox,
                                    "Modify with formula",
                                    "Minimum:")

        self.maxValueSpin= self.addVariantParameter(
                                    TaSpinBox,
                                    "Modify with formula",
                                    "Maximum:")
        self.min_maxValueCheckBox.registerEnabledWidgets([self.minValueSpin,
                                                          self.maxValueSpin])

        # The rescaling modification parameters
        self.newMinValueSpin = self.addVariantParameter(TaSpinBox,
                                                        "Rescale with final minimum and maximum values",
                                                        "Final minimum:")
        self.newMaxValueSpin = self.addVariantParameter(TaSpinBox,
                                                        "Rescale with final minimum and maximum values",
                                                        "Final maximum:")

        #Add advanced parameters



        self.fillDialog()
        self.showVariantWidgets(self.modificationModeComboBox.currentText())
        self.modificationModeComboBox.currentTextChanged.connect(self.showVariantWidgets)


    def setFieldsInLayer(self):
        self.formulaField.initOverrideButton("Formula", "Formula for\
                                             Topography modification",
                                             self.masksBox.currentLayer())
        self.minValueSpin.initOverrideButton("minValue",
                                              "Minimum bounding value",
                                              self.masksBox.currentLayer())
        self.maxValueSpin.initOverrideButton("maxValue",
                                              "Maximum bounding value",
                                              self.masksBox.currentLayer())
        self.newMinValueSpin.initOverrideButton("newMinValue",
                                              "Minimum value for rescaling",
                                              self.masksBox.currentLayer())
        self.newMaxValueSpin.initOverrideButton("newMaxValue",
                                              "Maximum value for rescaling",
                                              self.masksBox.currentLayer())
    def formulaValidation(self):
        H = random_generator().uniform(0.0, 1.0, (1800, 3600))  # [QGIS4 port]
        try:
            evaluate(self.formulaField.lineEdit.value(), {"H": H})  # [QGIS4 port]
        except Exception as e:
            self.msgBar.pushWarning("Warning:", f"The entered formula is invalid: {e}.")
